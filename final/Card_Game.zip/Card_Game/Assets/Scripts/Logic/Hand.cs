﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Hand : MonoBehaviour 
{
    public List<CardLogic> CardsInHand = new List<CardLogic>(); 

}
