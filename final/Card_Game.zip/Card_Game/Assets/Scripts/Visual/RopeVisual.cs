﻿using UnityEngine;
using System.Collections;

public class RopeVisual : MonoBehaviour {

	//initialisation
	void Start () {
	
	}
	
	// Update
	void Update () {
	
	}
}
