﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using DG.Tweening;



public class DamageEffect : MonoBehaviour {

    // affichage sang 
    public Sprite[] Splashes;

   
    public Image DamageImage;

    
    public CanvasGroup cg;

    
    public Text AmountText;

    void Awake()
    {
        
        DamageImage.sprite = Splashes[Random.Range(0, Splashes.Length)];  
    }

    
    private IEnumerator ShowDamageEffect()
    {
        // affichage
        cg.alpha = 1f;
        
        yield return new WaitForSeconds(1f);

        while (cg.alpha > 0)
        {
            cg.alpha -= 0.05f;
            yield return new WaitForSeconds(0.05f);
        }
       
        Destroy(this.gameObject);
    }

   
    public static void CreateDamageEffect(Vector3 position, int amount)
    {
        if (amount == 0)
            return;

        GameObject newDamageEffect = GameObject.Instantiate(GlobalSettings.Instance.DamageEffectPrefab, position, Quaternion.identity) as GameObject;
    
        DamageEffect de = newDamageEffect.GetComponent<DamageEffect>();
      
        if (amount < 0)
        {
           
            de.AmountText.text = "+" + (-amount).ToString();
            de.DamageImage.color = Color.green;
        }
        else
            de.AmountText.text = "-"+amount.ToString();
        
        de.StartCoroutine(de.ShowDamageEffect());
    }
}
