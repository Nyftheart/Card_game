﻿using UnityEngine;
using UnityEditor;

public static class ScriptableObjectUtility2 {
	

	/// <typeparam name="T">Type of scriptable object.</typeparam>
	public static void CreateAsset<T>() where T : ScriptableObject {
		var asset = ScriptableObject.CreateInstance<T>();
		ProjectWindowUtil.CreateAsset(asset, "New " + typeof(T).Name + ".asset");
	}
	
}