﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattlePhase : MonoBehaviour
{
    public GameObject ThisCard;
    public GameObject ThatCard;
    public Text EnemyPlayerHealth;

    void Update()
    {
        if(Input.GetMouseButtonDown(1))
        {
            Destroy(ThatCard);
            EnemyPlayerHealth.text = " Health : 17";
        }
    }
}
