﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SA
{
    [CreateAssetMenu(menuName = "Card Type/Spell")]
    public class SpellCard : ScriptableObject
    {

    }

}