﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using SA;

public class Mana : MonoBehaviour
{
    public SO.GameEvent currentPhase;
    public Text manaText;
    int mana = 2;

    

    void AddMana()
    {
        manaText.text = "Mana :" +  mana;
        mana = mana + 1;
    }
}
