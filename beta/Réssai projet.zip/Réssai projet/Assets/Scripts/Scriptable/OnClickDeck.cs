﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SA.GameElements;

public class OnClickDeck : MonoBehaviour
{
    public GameObject Card;
    int count = 0;
    public string[] startingCards;
    public SO.TransformVariable handGrid;
    public GE_Logic handLogic;
    public GameObject Card2;
    public GameObject Card3;
    public GameObject Card4;
    public GameObject Card5;
    public GameObject Card6;
    public GameObject Card7;
    public GameObject Card8;
    public GameObject Card9;
    





    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            if (count == 0)
            {
                int x = Random.Range(0, 8);
                if (x == 0)
                {

                    Instantiate(Card);
                    Debug.Log("Pioche");
                    count = count + 1;
                    
                }

                if (x == 1)
                {
                    Instantiate(Card2);
                    Debug.Log("Pioche");
                    count = count + 1;
                }


                if (x == 2)
                {
                    Instantiate(Card3);
                    Debug.Log("Pioche");
                    
                }

                if (x == 3)
                {
                    Instantiate(Card4);
                    Debug.Log("Pioche");
                    count = count + 1;
                }

                if (x == 4)
                {
                    Instantiate(Card5);
                    Debug.Log("Pioche");
                    count = count + 1;
                }

                if (x == 5)
                {
                    Instantiate(Card6);
                    Debug.Log("Pioche");
                    count = count + 1;
                }

                if (x == 6)
                {
                    Instantiate(Card7);
                    Debug.Log("Pioche");
                    count = count + 1;
                }

                if (x == 7)
                {
                    Instantiate(Card8);
                    Debug.Log("Pioche");
                    count = count + 1;
                }

                if (x == 8)
                {
                    Instantiate(Card9);
                    Debug.Log("Pioche");
                    count = count + 1;
                }
            }


            }
        }
    }

