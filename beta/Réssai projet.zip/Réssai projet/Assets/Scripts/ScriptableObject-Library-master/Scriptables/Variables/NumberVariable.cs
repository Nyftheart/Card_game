﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SO
{
    public class NumberVariable : ScriptableObject
    {
        //Base class for handling numeric variables, create subclasses if you are going to need other numeric variables such as uint etc.
    }
}
