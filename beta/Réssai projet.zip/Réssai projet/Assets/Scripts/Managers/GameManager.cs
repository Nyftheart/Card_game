﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SA.GameStates;

namespace SA
{ 
    public class GameManager : MonoBehaviour
    {
        public PlayerHolder currentPlayer;
        public State currentState;
        public GameObject cardPrefab;
        public int turnIndex;
        public Turn[] turns;
        public SO.GameEvent OnTurnChange;
        public SO.StringVariable turnText;
        public SO.GameEvent OnPhaseChange;


        public static GameManager gameManager;

        private static ResourcesManager _resourcesManager;


        public static ResourcesManager getResourcesManager()
        {
            if (_resourcesManager == null)
            {
               
                _resourcesManager = Resources.Load("ResourcesManager") as ResourcesManager;
                
            }

            return _resourcesManager;
        }
        public void Start()
        {
           Settings.gameManager = this;
            CreateStartingCards();
            turnText.value = turns[turnIndex].turnName;
            OnTurnChange.Raise();
        }

        public void CreateStartingCards()
        {
            ResourcesManager rm = GameManager.getResourcesManager();

            for(int i = 0; i < currentPlayer.startingCards.Length; i++)
            {
                GameObject go = Instantiate(cardPrefab) as GameObject;
                CardViz v = go.GetComponent<CardViz>();
                v.LoadCard(rm.GetCardInstance(currentPlayer.startingCards[i]));
                CardInstance inst = go.GetComponent<CardInstance>();
                inst.currentLogic = currentPlayer.handLogic;
                Settings.SetParentForCard(go.transform, currentPlayer.handGrid.value);
            }
        }


        private void Update()
        {
            bool isComplete = turns[turnIndex].Execute();
            if(isComplete)
            {
              
                turnIndex++;
                if(turnIndex > turns.Length - 1)
                {
                    turnIndex = 0;
                }

                turnText.value = turns[turnIndex].turnName;
                OnTurnChange.Raise();
            }
            if(currentState != null)
                currentState.Tick(Time.deltaTime);
        }

        public void SetState(State state)
        {
            currentState = state;
            
        }

        public void EndCurrentPhase()
        {
            turns[turnIndex].EndCurrentPhase();

        }
    }
}