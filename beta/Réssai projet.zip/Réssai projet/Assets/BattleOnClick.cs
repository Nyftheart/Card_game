﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattlePhasis : MonoBehaviour
{
    public GameObject ThisCard;
    public GameObject ThatCard;
    public Text EnemyPlayerHealth;
    public Text Vie;

    void Update()
    {
        if(Input.GetMouseButtonDown(1))
        {
            Destroy(ThatCard);
            EnemyPlayerHealth.text = " Health : 19";
            Vie.text = "4";
        }
    }
}
